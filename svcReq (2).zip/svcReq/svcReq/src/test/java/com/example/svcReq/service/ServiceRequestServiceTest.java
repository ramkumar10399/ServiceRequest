package com.example.svcReq.service;

import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;
import java.util.UUID;

@SpringBootTest
public class ServiceRequestServiceTest {

    @Mock
    private ServiceRequestRepository repository;

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private ServiceRequestService serviceRequestService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testUpdateServiceRequestStatusToComplete() {
        // Arrange
        UUID requestId = UUID.randomUUID();
        ServiceRequest request = new ServiceRequest();
        request.setId(requestId);
        request.setCurrentStatus(CurrentStatus.InProgress);
        request.setCreatedByEmail("test@example.com");

        ServiceRequest updatedRequest = new ServiceRequest();
        updatedRequest.setCurrentStatus(CurrentStatus.Complete);

        when(repository.findById(requestId)).thenReturn(Optional.of(request));
        when(repository.save(any(ServiceRequest.class))).thenReturn(request);

        // Act
        serviceRequestService.updateServiceRequest(requestId, updatedRequest);

        // Assert
        verify(notificationService, times(1))
                .sendServiceRequestCompletionNotification("test@example.com", request);
    }

    @Test
    public void testUpdateServiceRequestStatusWithoutCompletion() {
        // Arrange
        UUID requestId = UUID.randomUUID();
        ServiceRequest request = new ServiceRequest();
        request.setId(requestId);
        request.setCurrentStatus(CurrentStatus.InProgress);
        request.setCreatedByEmail("test@example.com");

        ServiceRequest updatedRequest = new ServiceRequest();
        updatedRequest.setCurrentStatus(CurrentStatus.Canceled);

        when(repository.findById(requestId)).thenReturn(Optional.of(request));
        when(repository.save(any(ServiceRequest.class))).thenReturn(request);

        // Act
        serviceRequestService.updateServiceRequest(requestId, updatedRequest);

        // Assert
        verify(notificationService, never()).sendServiceRequestCompletionNotification(anyString(), any());
    }
}
