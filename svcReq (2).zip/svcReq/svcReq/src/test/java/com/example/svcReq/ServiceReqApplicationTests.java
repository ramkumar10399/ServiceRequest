package com.example.svcReq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceReqApplicationTests {

	@Test
	void contextLoads() {
	}

}
