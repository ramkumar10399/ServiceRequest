package com.example.svcReq.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.internet.MimeMessage;

import static org.mockito.Mockito.*;

public class EmailNotificationServiceTest {

    @Mock
    private JavaMailSender mailSender;

    @InjectMocks
    private EmailNotificationService emailNotificationService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSendServiceRequestCompletionNotification() throws Exception {
        // Arrange
        String email = "customer@example.com";
        ServiceRequest request = new ServiceRequest();
        request.setId(UUID.randomUUID());
        request.setDescription("Fix the air conditioning");

        MimeMessage mimeMessage = mock(MimeMessage.class);
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

        // Act
        emailNotificationService.sendServiceRequestCompletionNotification(email, request);

        // Assert
        verify(mailSender, times(1)).send(mimeMessage);
    }
}
