package com.example.svcReq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceReqApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceReqApplication.class, args);
	}

}
