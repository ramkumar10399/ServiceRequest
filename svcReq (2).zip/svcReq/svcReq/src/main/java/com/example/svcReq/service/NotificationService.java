package com.example.svcReq.service;
public interface NotificationService {
    void sendServiceRequestCompletionNotification(String email, ServiceRequest request);
}
