package com.example.svcReq.service;

import com.example.servicerequest.exception.ResourceNotFoundException;
import com.example.servicerequest.model.CurrentStatus;
import com.example.servicerequest.model.ServiceRequest;
import com.example.servicerequest.repository.ServiceRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ServiceRequestService {

    private final ServiceRequestRepository repository;
    private final NotificationService notificationService;

    @Autowired
    public ServiceRequestService(ServiceRequestRepository repository, NotificationService notificationService) {
        this.repository = repository;
        this.notificationService = notificationService;
    }

    // Retrieve all service requests
    public List<ServiceRequest> getAllServiceRequests() {
        return repository.findAll();
    }

    // Retrieve a specific service request by ID
    public ServiceRequest getServiceRequestById(UUID id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Service Request not found with id: " + id));
    }

    // Create a new service request
    public ServiceRequest createServiceRequest(ServiceRequest serviceRequest) {
        serviceRequest.setId(UUID.randomUUID());
        serviceRequest.setCreatedDate(LocalDateTime.now());
        serviceRequest.setLastModifiedDate(LocalDateTime.now());
        return repository.save(serviceRequest);
    }

    // Update an existing service request by ID
    public ServiceRequest updateServiceRequest(UUID id, ServiceRequest updatedRequest) {
        Optional<ServiceRequest> existingRequestOpt = repository.findById(id);
        if (!existingRequestOpt.isPresent()) {
            throw new ResourceNotFoundException("Service Request not found with id: " + id);
        }

        ServiceRequest existingRequest = existingRequestOpt.get();
        existingRequest.setBuildingCode(updatedRequest.getBuildingCode());
        existingRequest.setDescription(updatedRequest.getDescription());
        existingRequest.setCurrentStatus(updatedRequest.getCurrentStatus());
        existingRequest.setLastModifiedBy(updatedRequest.getLastModifiedBy());
        existingRequest.setLastModifiedDate(LocalDateTime.now());

        // Save the updated request
        ServiceRequest savedRequest = repository.save(existingRequest);

        // Check if the status is changed to 'Complete' and send a notification
        if (updatedRequest.getCurrentStatus() == CurrentStatus.Complete) {
            notificationService.sendServiceRequestCompletionNotification(existingRequest.getCreatedByEmail(), savedRequest);
        }

        return savedRequest;
    }

    // Delete a service request by ID
    public void deleteServiceRequest(UUID id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Service Request not found with id: " + id);
        }
        repository.deleteById(id);
    }
}
