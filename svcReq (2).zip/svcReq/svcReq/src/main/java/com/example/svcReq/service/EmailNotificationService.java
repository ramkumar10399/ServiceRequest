package com.example.svcReq.service;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

@Service
public class EmailNotificationService implements NotificationService {

    private final JavaMailSender mailSender;

    public EmailNotificationService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Override
    public void sendServiceRequestCompletionNotification(String email, ServiceRequest request) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(email);
            helper.setSubject("Service Request Completed");
            helper.setText(buildEmailContent(request), true);

            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    private String buildEmailContent(ServiceRequest request) {
        return "<p>Dear Customer,</p>" +
                "<p>Your service request with ID: <strong>" + request.getId() + "</strong> has been completed.</p>" +
                "<p>Details: " + request.getDescription() + "</p>" +
                "<p>Thank you for using our services.</p>";
    }
}
