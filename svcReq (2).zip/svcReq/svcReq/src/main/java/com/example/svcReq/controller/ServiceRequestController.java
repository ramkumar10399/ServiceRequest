package com.example.svcReq.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/servicerequests")
public class ServiceRequestController {

    private final ServiceRequestService service;

    public ServiceRequestController(ServiceRequestService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<ServiceRequest>> getAllRequests() {
        List<ServiceRequest> requests = (List<ServiceRequest>) service.getAllServiceRequests();
        return requests.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(requests);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceRequest> getRequestById(@PathVariable UUID id) {
        return service.getServiceRequestById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ServiceRequest> createRequest(@RequestBody ServiceRequest request) {
        ServiceRequest createdRequest = service.createServiceRequest(request);
        return ResponseEntity.status(201).body(createdRequest);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ServiceRequest> updateRequest(@PathVariable UUID id, @RequestBody ServiceRequest request) {
        return ResponseEntity.ok(service.updateServiceRequest(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRequest(@PathVariable UUID id) {
        service.deleteServiceRequest(id);
        return ResponseEntity.noContent().build();
    }
}
